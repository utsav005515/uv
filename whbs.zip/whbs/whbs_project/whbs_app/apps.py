from django.apps import AppConfig


class WhbsAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'whbs_app'
