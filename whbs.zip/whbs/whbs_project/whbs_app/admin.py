from django.contrib import admin
from .models import *
# Register your models here.

admin.site.register(Hall)
admin.site.register(user_register)
admin.site.register(Booking)
admin.site.register(Msg)


